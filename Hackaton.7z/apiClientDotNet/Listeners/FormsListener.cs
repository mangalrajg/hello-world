﻿using apiClientDotNet.Models;
using Newtonsoft.Json.Linq;

namespace apiClientDotNet.Listeners
{
    public abstract class FormsListener
    {
        public virtual void onFormSubmit(JObject data) { }
    }
}
