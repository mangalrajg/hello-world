﻿using System;
using System.Collections.Generic;
using System.Text;

namespace apiClientDotNet.Models
{
    public class Datafeed
    {
        public string datafeedID { get; set; }
    }
}
