﻿using System;
using System.Collections.Generic;
using System.Text;

namespace apiClientDotNet.Models
{
    public class MemberList:List<RoomMember>
    {
    }
}
