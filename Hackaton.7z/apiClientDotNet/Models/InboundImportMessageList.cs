﻿using System;
using System.Collections.Generic;
using System.Text;

namespace apiClientDotNet.Models
{
    public class InboundImportMessageList:List<InboundImportMessage> {
    }
}
