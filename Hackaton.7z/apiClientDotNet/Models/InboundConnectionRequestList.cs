﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace apiClientDotNet.Models
{
    public class InboundConnectionRequestList:List<InboundConnectionRequest>
    {
    }
}
