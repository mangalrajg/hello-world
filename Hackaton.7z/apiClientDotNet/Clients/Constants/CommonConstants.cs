﻿using System;
using System.Collections.Generic;
using System.Text;

namespace apiClientDotNet.Clients.Constants
{
    public class CommonConstants
    {
        public static string HTTPSPREFIX = "https://";
    }
}
