using System;
using System.IO;
using apiClientDotNet.Models;
using apiClientDotNet;
using apiClientDotNet.Listeners;
using apiClientDotNet.Services;
using apiClientDotNet.Models.Events;
using System.Diagnostics;
using apiClientDotNet.Authentication;
using System.Threading.Tasks;
using RequestResponse.Core;
using Newtonsoft.Json.Linq;

namespace RequestResponse
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = Path.GetFullPath("config.json");
            var conf = new SymConfig
            {
                sessionAuthHost = "develop2.symphony.com",
                keyAuthHost = "develop2.symphony.com",
                podHost = "develop2.symphony.com",
                agentHost = "develop2.symphony.com",
                botUsername = "firm1_hackathon_bot_109",
                botEmailAddress = "firm1_hackathon_bot_109@devmeetup.com",
                botPrivateKeyName = "rsa-private-megabot.pem",
                botPrivateKeyPath = @"C:\temp\sgbot\certs\",
                sessionProxyPassword = "",
                sessionProxyURL = "",
                sessionProxyUsername = "",
                proxyURL = "",
                proxyPassword = "",
                proxyUsername = "",
                sessionAuthPort = 443,
                keyAuthPort = 443,
                agentPort = 443,
                podPort = 443
            }; ;
            var auth = new SymBotRSAAuth(conf);
            auth.authenticate();
            SymBotClient symBotClient = SymBotClient.initBot(conf, auth);
            DatafeedEventsService datafeedEventsService = new DatafeedEventsService(symBotClient);

            var engine = new BotEngine(symBotClient);
            RoomListener botLogic = new BotLogic(symBotClient, engine);
            datafeedEventsService.addRoomListener(botLogic);
            datafeedEventsService.addFormsListener(new MyFormsListener(symBotClient, engine));
            datafeedEventsService.addIMListener(new ImListener());


            Console.WriteLine("Waiting for events");
            datafeedEventsService.getEventsFromDatafeed();

        }
    }


    public class MyFormsListener : FormsListener
    {
        public MyFormsListener(SymBotClient client, BotEngine botEngine)
        {
            Client = client;
            BotEngine = botEngine;
        }

        public SymBotClient Client { get; }
        public BotEngine BotEngine { get; }

        public override void onFormSubmit(JObject data)
        {
            this.BotEngine.OnFormSubmitted(data);
        }
    }

    public class BotLogic : RoomListener
    {
        public SymBotClient Client { get; }
        public BotEngine BotEngine { get; }

        public BotLogic(SymBotClient client, BotEngine botEngine)
        {
            Client = client;
            BotEngine = botEngine;
        }
        public void onRoomMessage(Message inboundMessage)
        {
            BotEngine.ProcessInputMessage(inboundMessage);
        }
        public void onRoomCreated(RoomCreated roomCreated) { }
        public void onRoomDeactivated(RoomDeactivated roomDeactivated) { }
        public void onRoomMemberDemotedFromOwner(RoomMemberDemotedFromOwner roomMemberDemotedFromOwner) { }
        public void onRoomMemberPromotedToOwner(RoomMemberPromotedToOwner roomMemberPromotedToOwner) { }
        public void onRoomReactivated(apiClientDotNet.Models.Stream stream) { }
        public void onRoomUpdated(RoomUpdated roomUpdated) { }
        public void onUserJoinedRoom(UserJoinedRoom userJoinedRoom) { }
        public void onUserLeftRoom(UserLeftRoom userLeftRoom) { }
    }

    public class ImListener : IMListener
    {
        public override void onIMMessage(Message message)
        {
            base.onIMMessage(message);
        }
    }
}
