﻿using HtmlAgilityPack;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace RequestResponse
{
    public static class StringExtensions
    {
        internal static string RemoveNumericIndex(this string s)
        {
            if (Regex.IsMatch(s, "([0-9]{0,3}-)(.)+"))
            {
                var idx = s.IndexOf('-');
                return s.Substring(idx);
            }

            return s;
        }

        internal static string CleanifySection(this string s, string opening, string closing)
        {
            var openIdx = s.IndexOf(opening);
            var closeIdx = s.IndexOf(closing);

            if (openIdx == -1 || closeIdx == -1)
                return s;

            return s.Substring(0, openIdx) +
                   (closeIdx < s.Length ? s.Substring(closeIdx + 1) : "");
        }



        internal static string ReplaceNonAlphabetical(this string str)
        {

            var sb = new StringBuilder();
            foreach (var c in str)
            {
                if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z'))
                {
                    sb.Append(c);
                }
                else
                {
                    switch (c)
                    {
                        case 'ç':
                            sb.Append("c");
                            break;
                        case 'à':
                        case 'â':
                            sb.Append("a");
                            break;
                        case 'é':
                        case 'è':
                        case 'ê':
                        case 'ë':
                            sb.Append("e");
                            break;
                        case 'ü':
                        case 'û':
                        case 'ù':
                            sb.Append('u');
                            break;
                        case 'î':
                        case 'ï':
                            sb.Append("i");
                            break;
                        case 'ô':
                        case 'Ö':
                            sb.Append('o');
                            break;
                        default:
                            sb.Append(' ');
                            break;
                    }
                }
            }
            return sb.ToString();
        }

        internal static T ToEnum<T>(this string s, bool ignoreCase)
        {
            return (T)Enum.Parse(typeof(T), s, ignoreCase);
        }

        /// <summary>
        /// Converts HTML to plain text / strips tags.
        /// </summary>
        /// <param name="html">The HTML.</param>
        /// <returns></returns>
        internal static string ToPlainText(this string html)
        {
            var doc = new HtmlDocument();
            doc.LoadHtml(html);

            var sw = new StringWriter();
            ConvertTo(doc.DocumentNode, sw);
            sw.Flush();
            return sw.ToString();
        }


        /// <summary>
        /// Count the words.
        /// The content has to be converted to plain text before (using ConvertToPlainText).
        /// </summary>
        /// <param name="plainText">The plain text.</param>
        /// <returns></returns>
        internal static int CountWords(string plainText)
        {
            return !String.IsNullOrEmpty(plainText) ? plainText.Split(' ', '\n').Length : 0;
        }


        internal static string Cut(string text, int length)
        {
            if (!String.IsNullOrEmpty(text) && text.Length > length)
            {
                text = text.Substring(0, length - 4) + " ...";
            }
            return text;
        }

        internal static string ToMaj(this string text)
        {
            if (string.IsNullOrEmpty(text))
                return text;

            text = text.Trim().ToLower();

            var str = (text[0] + "").ToUpper();
            for (var i = 1; i < text.Length; i++)
            {
                str += text[i - 1] == ' '
                    ? (text[i] + "").ToUpper()
                    : text[i] + "";
            }
            return str;
        }

        internal static string RevertName(this string text)
        {
            if (string.IsNullOrEmpty(text))
                return text;

            var multiparts = text.Split('&');
            if (multiparts.Length > 1)
            {
                var res = string.Join("&", multiparts.Select(x => x.RevertName()));
                return res;
            }

            if (text.Contains("-"))
                return text.Split('-').Last().RevertName();

            var parts = text.Split(' ');

            if (!(parts.Length > 1))
                return text;

            var first = parts[0];

            var last = string.Join(" ", parts.Where((x, idx) => idx > 0).ToArray());

            return (last + " " + first).ToMaj();
        }


        internal static void ConvertContentTo(HtmlNode node, TextWriter outText)
        {
            foreach (var subnode in node.ChildNodes)
            {
                ConvertTo(subnode, outText);
            }
        }


        internal static void ConvertTo(HtmlNode node, TextWriter outText)
        {
            string html;
            switch (node.NodeType)
            {
                case HtmlNodeType.Comment:
                    // don't output comments
                    break;

                case HtmlNodeType.Document:
                    ConvertContentTo(node, outText);
                    break;

                case HtmlNodeType.Text:
                    // script and style must not be output
                    var parentName = node.ParentNode.Name;
                    if ((parentName == "script") || (parentName == "style"))
                        break;

                    // get text
                    html = ((HtmlTextNode)node).Text;

                    // is it in fact a special closing node output as text?
                    if (HtmlNode.IsOverlappedClosingElement(html))
                        break;

                    // check the text is meaningful and not a bunch of whitespaces
                    if (html.Trim().Length > 0)
                    {
                        outText.Write(HtmlEntity.DeEntitize(html));
                    }
                    break;

                case HtmlNodeType.Element:
                    switch (node.Name)
                    {
                        case "p":
                            // treat paragraphs as crlf
                            outText.Write("\r\n");
                            break;
                        case "br":
                            outText.Write("\r\n");
                            break;
                    }

                    if (node.HasChildNodes)
                    {
                        ConvertContentTo(node, outText);
                    }
                    break;
            }
        }
    }
}
