﻿using apiClientDotNet;
using apiClientDotNet.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace RequestResponse.Core
{
    public class BotEngine
    {
        private JObject LastQuoteContext;

        public BotEngine(SymBotClient client)
        {
            Client = client;
        }

        public SymBotClient Client { get; }

        public void ProcessInputMessage(Message msg)
        {
            try
            {
                var rawTxt = msg.message.ToPlainText();
                if (rawTxt.ToLower().Contains("price"))
                {
                    ShowPricingForm(msg);
                }
                if (rawTxt.ToLower().Contains("recap"))
                {
                    ShowRecap(msg).Wait();
                }
                if (rawTxt.ToLower().Contains("help"))
                {
                    HelpRequested().Wait();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to process msg: " + e.Message + "\n" + e.StackTrace);
            }

        }

        private async Task ShowRecap(Message msgSym)
        {
            var msg = "Here is a prices recap for the day<br/><table>";

            using (var cli = new HttpClient())
            {
                var res = await cli.GetAsync(Constants.RecapApi);
                var str = await res.Content.ReadAsStringAsync();
                var datas = JArray.Parse(str);
                foreach (var data in datas)
                {
                    var product = data["product"].ToString();
                    var notional = data["notional"].ToString();
                    var maturity = data["maturity"].ToString();
                    var currency = data["currency"].ToString();
                    var underlyings = data["underlyings"].ToString();
                    var price = float.Parse(data["price"].ToString());

                    msg += "<tr>"
                        + "<td>Product</td>" + $"<td>{product}</td>"
                        + "<td>Notional</td>" + $"<td>{notional}</td>"
                        + "<td>Maturity</td>" + $"<td>{maturity}</td>"
                        + "<td>Currency</td>" + $"<td>{currency}</td>"
                        + "<td>Underlyings</td>" + $"<td>{underlyings}</td>"
                        + "<td>Price</td>" + $"<td>{price}</td>"
                        + "</tr>";

                }
            }

            msg += "</table>";

            SendMsg(Constants.RecapRoomId, msg);
        }

        private void ShowPricingForm(Message msg)
        {
            var roomId = Constants.ClientRoomId;
            var formPath = Path.Combine(Constants.FormsFilesFolder, "pricing.xml");
            SendMsg(roomId, File.ReadAllText(formPath));
        }

        private void SendMsg(string roomId, string msg)
        {
            Client.getMessagesClient().sendMessage(roomId, new OutboundMessage
            {
                message = msg,
                attachments = new List<FileStream>()
            }, true);
        }

        internal void OnFormSubmitted(JObject data)
        {
            var action = data["formValues"]["action"].ToString();
            switch (action.ToLower().Trim())
            {
                case "price_button":
                    ProcessUserPricingRequestAsync(data).Wait();
                    break;
                case "trade_button":
                    ProcessTrade(data).Wait();
                    break;
                case "refresh_price_button":
                    ProcessUserPricingRequestAsync(LastQuoteContext).Wait();
                    break;
                case "help_button":
                    HelpRequested().Wait();
                    break;
                case "help_submit_button":
                    HandleHelpRequest(data).Wait();
                    break;
            }
        }

        private async Task HandleHelpRequest(JObject data)
        {
            var cmt = data["formValues"]["msg"].ToString();
            //var sales = data["formValues"]["sales"];

            var msg = $"<mention email='sylvain.salvetti@sgcib.com'/> is asking for your help with the following comment:<br/><i> " + cmt + "</i>";
            SendMsg(Constants.SupportRoomId, msg);
        }

        private async Task HelpRequested()
        {
            var path = Path.Combine(Constants.FormsFilesFolder, "help.xml");
            SendMsg(Constants.ClientRoomId, File.ReadAllText(path));
        }

        private async Task ProcessTrade(JObject tmpData)
        {
            var data = LastQuoteContext;
            var product = data["formValues"]["product"].ToString();
            var notional = data["formValues"]["notional"].ToString();
            var maturity = data["formValues"]["maturity"].ToString();
            var currency = data["formValues"]["currency"].ToString();
            var underlyings = data["formValues"]["underlyings"].ToString();

            var str = $"<mention email='sylvain.salvetti@sgcib.com'/>, The trade {product} {currency} {notional} {underlyings} has been booked<br/>Reference <hash tag='{Guid.NewGuid().ToString()}'/>";
            SendMsg(Constants.SalesRoomId, str);

            SendMsg(Constants.ClientRoomId, str);
        }

        private async Task ProcessUserPricingRequestAsync(JObject data)
        {
            var product = data["formValues"]["product"].ToString();
            var notional = data["formValues"]["notional"].ToString();
            var maturity = data["formValues"]["maturity"].ToString();
            var currency = data["formValues"]["currency"].ToString();
            var underlyings = data["formValues"]["underlyings"].ToString();

            var price = 0f;
            using (var cli = new HttpClient())
            {
                var res = await cli.PostAsync(Constants.PriceApi, new StringContent(data["formValues"].ToString(), Encoding.UTF8, "application/json"));
                var str = await res.Content.ReadAsStringAsync();
                var dataPricing = JObject.Parse(str);
                //quoteId = int.Parse(dataPricing["quoteId"].ToString());
                price = float.Parse(dataPricing["price"].ToString());

            }

            LastQuoteContext = data;

            var tradeStr = File.ReadAllText(Path.Combine(Constants.FormsFilesFolder, "trade.xml"));
            var msg = string.Format(tradeStr, price, product, currency, maturity, notional, underlyings);

            SendMsg(Constants.ClientRoomId, msg);
        }
    }
}
