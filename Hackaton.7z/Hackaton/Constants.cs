﻿namespace RequestResponse
{
    public class Constants
    {
        public const string PriceApi = "http://192.168.41.227:5050/price/";
        public const string RecapApi = "http://192.168.41.227:5050/recap/";
        public const string ClientRoomId = "Yt-VX9YzNbai5TFcu0wMJH___pKhzFA_dA";
        public const string SalesRoomId = "iKLSOTtDjOhYd-wJHRNm6H___pKhyymKdA";
        public const string SupportRoomId = "rgV_9UyDWxmxva8FX6Bfyn___pKhycFJdA";
        public const string RecapRoomId = "iJg6TjUNfkXdwtK1tUmO+X___pKhyPKtdA";

        public const string FormsFilesFolder = @"C:\temp\sgbot\forms";
    }
}
